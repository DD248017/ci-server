package dd2480.group17.ciserver.service;

public class GitServiceTest {
}
